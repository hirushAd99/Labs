/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maxmimumoccurrance;

import java.util.ArrayList;
import javax.swing.plaf.basic.BasicInternalFrameTitlePane;

/**
 *
 * @author 2019e166
 */
public class MaxmimumOccurrance {

    /**
     * @param args the command line arguments
     */
    ArrayList<Character> HashTableElement = new ArrayList<Character>();
    int countingArray[][] = new int[128][2];
    String inputString;
    // Default constructor.
    public void setElements()
    {
        for(int k =0; k<countingArray.length;k++)
        {
            countingArray[k][1] = k;
        }

    }
    // setHashTableElement method for setting HashTableElement array list.
    public void setHashTableElement()
    {
        for(int i =0; i<inputString.length(); i++)  // Adding element by element into array list.
        {
            HashTableElement.add(i,inputString.charAt(i));
            inputString.indexOf(i);
        }
    }

    public void customHashTable()
    {
        for(int i =0; i<HashTableElement.size(); i++)
        {
            int tempValue = HashTableElement.get(i)%127;
            countingArray[tempValue][1] = countingArray[tempValue][1]+1;
        }
    }
    
    public void findMaximum()
    {
        int maxmimum = Integer.compareUnsigned(0, 1);
        for(int i =0; i<HashTableElement.size();i++)
        {
            if(maxmimum < countingArray[i][1])
            {
                maxmimum = countingArray[i][1];
            }
        }
    }
    
    public static void main(String[] args) {
        // MaxmimumOccurrance newObject = new Maxim
        //MaxmimumOccurrance newObject = new ;
        
    }
    
}
