/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maximumoccurrence;
import java.util.ArrayList;
/**
 *
 * @author 2019e166
 */
public class MaximumOccurrence {

    /**
     * @param args the command line arguments
     */
    int sizeOfArrayList ;
    int key;
    int value;
    ArrayList<Integer> hashTableElement = new ArrayList<>(sizeOfArrayList);
    int countingArray[][] = new int[128][2];
    
    public void node(int key , int value)
    {
        this.key = key;
        this.value = value;
        setValue(key, value);
        addElement(value);
    }
    
    public void size(int sizeOfArrayList)
    {
        this.sizeOfArrayList = sizeOfArrayList;
    }
    
    public void setValue(int key,int value)
    {
        int tempValue = key%128;
        isEmpty(value); 
        countingArray[tempValue][1] = tempValue;
    }
    
    public void addElement(int indexValue)
    {
        int tempValue = indexValue%128;
        countingArray[tempValue][1] = countingArray[tempValue][1]++;
    }
    
    public boolean isEmpty(int indexOfChecking)
    {
        boolean isEmpty = false;
        if(countingArray[indexOfChecking][1] == 0)
        {
            isEmpty = true;
        }
        return isEmpty;
    }
    
    public void removeElement(int removingIndex)
    {
        boolean checkEmpty = isEmpty(removingIndex);
        if(checkEmpty == false)
        {
            hashTableElement.remove(removingIndex);
        }
    }
    
   public static void main(String[] args) {
       MaximumOccurrence newObject = new MaximumOccurrence();
       newObject.size(6);
       int[] newArray = new int[6];
       String x = "Apple";
       for(int i=0; i<x.length(); i++)
       {
           newArray[i] = x.charAt(i);
       }
       newObject.node(12,'A');
       
        // TODO code application logic here
    }
    
}
