/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab06;

import java.util.ArrayList;

/**
 *
 * @author 2019e166
 */
public class Lab06 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        ArrayList<String> newArray = new ArrayList<>(3);
        newArray.add(0,"Sydney");
        newArray.add(1,"Colombo");
        newArray.add("Chicago");
        String city01 = "Colombo";
        String city02 = "Chicago";
        if(city01.compareTo(city02)>0)
        {
            String temp = city01;
            city01 = city02;
            city02 = temp;
            System.out.println(city01 + "  " + city02);
        }
        else
            System.out.println("False");
        /*
        for (int i = 0; i < newArray.size(); i++) 
        {
            for (int j = i + 1; j < newArray.size(); j++)
            { 
                if(newArray.get(i).compareTo(newArray.get(j)) > 0)
                {
                    String temp = newArray.get(i);
                    newArray.add(i, newArray.get(j));
                    newArray.add(j, temp);
                }
            }
               
        }
*/
      
    }
    
}
