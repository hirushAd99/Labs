/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab06;

import java.util.ArrayList;

/**
 *
 * @author 2019e166
 */
public class CityDatabase {
    
        int root;
        int leftNode;
        int rightNode;
        String cityName;
        double latitude;
        double longitude;

        public void Node()
        {
            root = 0;
            leftNode = 0;
            rightNode =0;
            cityName = "";
            latitude = 0.0;
            longitude = 0.0;
        }
        public void setRootAndNode(int root , int leftNode , int rightNode)
        {
            this.root = root;
            this.leftNode = leftNode;
            this.rightNode = rightNode;
        }
        public void setNode(String cityName , double latitude , double longitude)
        {
            this.cityName = cityName;
            this.latitude = latitude;
            this.longitude = longitude;
        }

   ArrayList<String> cityDataBase = new ArrayList<>(10);
   public void setcitydataBase()
   {
       for(int i =0; i<cityDataBase.size(); i++)
           cityDataBase.add("0");
   }
    public void insert(String city , double latitudeDistance , double longitudeDistance)
    {
        //Node newNode = new Node();
        //newNode.setNode(city,latitudeDistance,longitudeDistance);
        
        if((cityDataBase.get(0))!=" ")
        {
            int i =1;
            while(i != 0)
            {
                boolean city02High = alphabeticalOrder(cityDataBase.get(i), city);
                if(city02High == true)
                {
                    if("0".equals(cityDataBase.get(2*i+1)))
                    {
                        cityDataBase.add(2*i+1, city);
                    }
                    else
                    {
                        city02High = alphabeticalOrder(cityDataBase.get(i), city);
                    }
                    i--;
                }
                else
                {
                    if(cityDataBase.get(2*i) == "0")
                    {
                        cityDataBase.add(2*i, city);
                    }
                    else
                    {
                        city02High = alphabeticalOrder(cityDataBase.get(i), city);
                    }
                    i--;
                }
            }
        }
            else
                cityDataBase.add(0,city);
        

        System.out.println(cityDataBase);

    }

    public boolean alphabeticalOrder(String city01 , String city02)
    {
        return city01.compareTo(city02)>0;      
    }
    
    public static void main(String[] args) {
        CityDatabase newObject01 = new CityDatabase();
        CityDatabase newObject02 = new CityDatabase();
        newObject01.setcitydataBase();
        newObject01.insert("Colombo", 6.927079, 79.861244);
        newObject01.insert("Chicago",41.88183,-87.62317);
    }
}
