public class TestCircle {
    public static void main(String[] args) {
        Circle circle01 = new Circle();
        System.out.println("Radius of circle : " + circle01.getRadius());
        System.out.println("Color of circle : " + circle01.getColor());
        System.out.println("Area of circle : " + circle01.getArea());

    }
}
