/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package reverseword;

/**
 *
 * @author 2019e166
 */
public class ReverseWord {
    int arraySize;
    char[] wordArray = new char[arraySize];
    String word;
    public void getWord(String word)
    {
        this.word = word;
    }
    public void setReverse()
    {
        arraySize = word.length();
        for(int i =0; i < arraySize; i++)
        {
            //wordArray = 
        }
    }
    }
    

