public class TestDelimiterMatching {
    public static void main(String[] args) {
        DelimitersMatching newObject = new DelimitersMatching();
        newObject.setDelimiter();
        newObject.setCharacters();
    }
}