public class TestReverseWord {
    public static void main(String[] args) {
        ReverseWord newObject = new ReverseWord();
        newObject.setWord();
    }
}
