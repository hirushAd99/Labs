public class TestLinkList {
    public static void main(String[] args) {

    }
}
