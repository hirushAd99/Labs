import java.util.Scanner;
public class CircularLinkedList {
    Scanner scanner = new Scanner(System.in);
    int numberOfPeople;
    int numberCountingOff;
    int[] arrayElement = new int[numberOfPeople];

    public CircularLinkedList()
    {
        numberOfPeople = 0;
        numberCountingOff = 0;
    }
    public void setElement()
    {
        System.out.println("Enter the number of people in the circle (n) : ");
        numberOfPeople = scanner.nextInt();
        System.out.println("Enter the number used for counting off (m) :");
        numberCountingOff = scanner.nextInt();
        int[] buildArray = new int[numberOfPeople];
        for(int i =0; i < numberOfPeople;i++)
        {
            buildArray[i] = i+1;
        }
        arrayElement = buildArray;
    }
    public void committedSuicide(int startingIndex)
    {
        for(int i = startingIndex; i <numberOfPeople-1; i+=numberCountingOff)
        {
            System.out.println(arrayElement[i+numberCountingOff-1]);
            arrayElement[i+numberCountingOff-1] = 0;
            //System.out.println(arrayElement[i+numberCountingOff-1]);
        }
        for(int j =0; j <numberOfPeople; j++)
        {
            while (arrayElement[j] != 0)
            {
                committedSuicide(j);
            }
        }

    }

    public static void main(String[] args) {
        CircularLinkedList newObject = new CircularLinkedList();
        newObject.setElement();
        newObject.committedSuicide(0);
    }
}
