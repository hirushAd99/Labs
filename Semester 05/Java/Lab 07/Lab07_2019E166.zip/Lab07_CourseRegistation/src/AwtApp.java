import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AwtApp extends Frame implements ActionListener{
    Label studentName;
    Label studentRegistrationNumber;
    Label courseDetails;
    Label courseCode;
    Label course;
    Label courseCredit;
    Label course01;
    Label course02;
    Label course03;
    Label email;
    Label advisorName;
    TextField studentNameText;
    TextField regNumberText;
    TextField courseCodeText1;
    TextField courseText1;
    TextField courseCreditText1;
    TextField courseCodeText2;
    TextField courseText2;
    TextField courseCreditText2;
    TextField courseCodeText3;
    TextField courseText3;
    TextField courseCreditText3;
    TextField emailText;
    TextField advisorNameText;
    Button submitButton;
    Button resetButton;
    Frame frame = new Frame();
    Frame frameDetails = new Frame();
    Button exitButton;

    AwtApp(){
        studentName = new Label("Student Name");
        studentName.setBounds(20,50,150,20);
        studentNameText = new TextField();
        studentNameText.setBounds(180,50,320,20);
        studentRegistrationNumber = new Label("Registration Number");
        studentRegistrationNumber.setBounds(20,80,150,20);
        regNumberText = new TextField();
        regNumberText.setBounds(180,80,320,20);
        courseDetails = new Label("Course Details");
        courseDetails.setBounds(20,110,150,20);
        courseCode = new Label("Course Code");
        courseCode.setBounds(180,110,80,20);
        course = new Label("Course");
        course.setBounds(320,110,60,20);
        courseCredit = new Label("Course Credit");
        courseCredit.setBounds(420,110,80,20);
        course01 = new Label("Course 01");
        course01.setBounds(20,140,150,20);
        courseCodeText1 = new TextField();
        courseCodeText1.setBounds(180,140,70,20);
        courseText1 = new TextField();
        courseText1.setBounds(260,140,150,20);
        courseCreditText1 = new TextField();
        courseCreditText1.setBounds(420,140,80,20);
        course02 = new Label("Course 02");
        course02.setBounds(20,170,150,20);
        courseCodeText2 = new TextField();
        courseCodeText2.setBounds(180,170,70,20);
        courseText2 = new TextField();
        courseText2.setBounds(260,170,150,20);
        courseCreditText2 = new TextField();
        courseCreditText2.setBounds(420,170,80,20);
        course03 = new Label("Course 03");
        course03.setBounds(20,200,150,20);
        courseCodeText3 = new TextField();
        courseCodeText3.setBounds(180,200,70,20);
        courseText3 = new TextField();
        courseText3.setBounds(260,200,150,20);
        courseCreditText3 = new TextField();
        courseCreditText3.setBounds(420,200,80,20);
        email= new Label("Email");
        email.setBounds(20,230,150,20);
        emailText= new TextField();
        emailText.setBounds(180,230,320,20);
        advisorName = new Label("Advisor Name");
        advisorName.setBounds(20,260,150,20);
        advisorNameText = new TextField();
        advisorNameText.setBounds(180,260,320,20);
        submitButton = new Button("Submit");
        submitButton.setBackground(Color.blue);
        submitButton.setBounds(140,300,80,20);
        resetButton = new Button("Reset");
        resetButton.setBackground(Color.red);
        resetButton.setBounds(320,300,80,20);

        frame.add(studentName);
        frame.add(studentNameText);
        frame.add(studentRegistrationNumber);
        frame.add(regNumberText);
        frame.add(courseDetails);
        frame.add(courseCode);
        frame.add(course);
        frame.add(courseCredit);
        frame.add(course01);
        frame.add(courseCodeText1);
        frame.add(courseText1);
        frame.add(courseCreditText1);
        frame.add(course02);
        frame.add(courseCodeText2);
        frame.add(courseText2);
        frame.add(courseCreditText2);
        frame.add(course03);
        frame.add(courseCodeText3);
        frame.add(courseText3);
        frame.add(courseCreditText3);
        frame.add(email);
        frame.add(emailText);
        frame.add(advisorName);
        frame.add(advisorNameText);
        frame.add(submitButton);
        frame.add(resetButton);
        frame.setSize(550,380);
        frame.setBackground(Color.GRAY);
        frame.setLayout(null);
        frame.setVisible(true);
        frame.setTitle("Course Registration");
    }

    public void exit()
    {
        frameDetails.setVisible(false);
    }

    public void showDetails(String[] studentDetails)
    {
        frame.setVisible(false);
        frameDetails.add(studentName);
        Label name = new Label(studentDetails[0]);
        name.setBounds(180,50,320,20);
        frameDetails.add(name);
        frameDetails.add(studentRegistrationNumber);
        Label reg = new Label(studentDetails[1]);
        reg.setBounds(180,80,320,20);
        frameDetails.add(reg);
        frameDetails.add(courseDetails);
        frameDetails.add(courseCode);
        frameDetails.add(course);
        frameDetails.add(courseCredit);
        frameDetails.add(course01);
        Label courseCode1 = new Label(studentDetails[2]);
        courseCode1.setBounds(180,140,70,20);
        frameDetails.add(courseCode1);
        Label course1 = new Label(studentDetails[3]);
        course1.setBounds(260,140,150,20);
        frameDetails.add(course1);
        Label courseCred1 = new Label(studentDetails[4]);
        courseCred1.setBounds(420,140,80,20);
        frameDetails.add(courseCred1);
        frameDetails.add(course02);
        Label courseCode2 = new Label(studentDetails[5]);
        courseCode2.setBounds(180,170,70,20);
        frameDetails.add(courseCode2);
        Label course2 = new Label(studentDetails[6]);
        course2.setBounds(260,170,150,20);
        frameDetails.add(course2);
        Label courseCred2 = new Label(studentDetails[7]);
        courseCred2.setBounds(420,170,80,20);
        frameDetails.add(courseCred2);
        frameDetails.add(course03);
        Label courseCode3 = new Label(studentDetails[8]);
        courseCode3.setBounds(180,200,70,20);
        frameDetails.add(courseCode3);
        Label course3 = new Label(studentDetails[9]);
        course3.setBounds(260,200,150,20);
        frameDetails.add(course3);
        Label courseCred3 = new Label(studentDetails[10]);
        courseCred3.setBounds(420,200,80,20);
        frameDetails.add(courseCred3);
        frameDetails.add(email);
        Label eMail = new Label(studentDetails[11]);
        eMail.setBounds(180,230,320,20);
        frameDetails.add(eMail);
        frameDetails.add(advisorName);
        Label advisor = new Label(studentDetails[12]);
        advisor.setBounds(180,260,320,20);
        frameDetails.add(advisor);

        frameDetails.setSize(550,380);
        frameDetails.setBackground(Color.cyan);
        frameDetails.setLayout(null);
        frameDetails.setVisible(true);
        frameDetails.setTitle("Student Details");
    }

    public void actionPerformance()
    {
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String[] studentDetails = new String[13];
                studentDetails[0] = studentNameText.getText();
                studentDetails[1] = regNumberText.getText();
                studentDetails[2] = courseCodeText1.getText();
                studentDetails[3] = courseText1.getText();
                studentDetails[4] = courseCreditText1.getText();
                studentDetails[5] = courseCodeText2.getText();
                studentDetails[6] = courseText2.getText();
                studentDetails[7] = courseCreditText2.getText();
                studentDetails[8] = courseCodeText3.getText();
                studentDetails[9] = courseText3.getText();
                studentDetails[10] = courseCreditText3.getText();
                studentDetails[11] = emailText.getText();
                studentDetails[12] = advisorNameText.getText();
                showDetails(studentDetails);
            }
        }
        );

        resetButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                studentNameText.setText(null);
                regNumberText.setText(null);
                courseCodeText1.setText(null);
                courseText1.setText(null);
                courseCreditText1.setText(null);
                courseCodeText2.setText(null);
                courseText2.setText(null);
                courseCreditText2.setText(null);
                courseCodeText3.setText(null);
                courseText3.setText(null);
                courseCreditText3.setText(null);
                emailText.setText(null);
                advisorNameText.setText(null);
            }
        });

            }

    public static void main(String[] args) {
        AwtApp awtApp = new AwtApp();
        awtApp.actionPerformance();

    }
    @Override
    public void actionPerformed(ActionEvent e) {
        actionPerformance();
    }
}
