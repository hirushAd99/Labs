public class insufficientBalance extends NumberFormatException{
    public insufficientBalance(Exception e) {
    }

    public void checkBalance(double balance, double withdrawAmount)
    {
        if(balance < withdrawAmount)
        {
            System.out.println("You cannot withdraw this amount.");
            return;
        }
    }
}
