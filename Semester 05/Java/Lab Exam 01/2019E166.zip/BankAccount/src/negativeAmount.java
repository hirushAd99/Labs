public class negativeAmount extends Exception{



    public String checkNegative(double amount)
    {
        String msg = null;
        if(amount < 0)
            System.out.println("Credit is negative value.");
        return msg;
    }

    public String checkBalance(double balance, double withdrawAmount)
    {
        String msg = null;
        if(balance < withdrawAmount)
        {
            System.out.println("You cannot withdraw this amount.");
        }
        return msg;
    }



}
