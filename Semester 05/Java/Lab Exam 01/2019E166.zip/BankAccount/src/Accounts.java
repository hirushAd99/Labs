public class Accounts extends negativeAmount{
    private double balance;
    private int accountNumber;

    public Accounts(double initialBalance, int accountNumber) {
        if (initialBalance > 0.0)
            balance = initialBalance;
    }

    public void credit(double amount) throws negativeAmount {
        try {
            checkNegative(amount);

        }
         catch (Exception e) {
             System.out.println(e);
             balance = balance + amount;
        }
    }

    public void withdraw(double amount) throws negativeAmount {
        try {
            checkBalance(balance,amount);

        }catch (Exception e)
        {
            System.out.println(e);
            balance = balance - amount;
        }



    }

    public double getBalance() {
        return balance;
    }

    public int getAccountNumber() {
        return this.accountNumber;
    }


    public static void main(String[] args) throws negativeAmount,insufficientBalance
    {
        Accounts accounts = new Accounts(2000,156378267);
        int accountNumber1 = accounts.accountNumber;
        System.out.println(accountNumber1);
        accounts.credit(-2000);

        System.out.println(accounts.getBalance());
        accounts.withdraw(10000);
        System.out.println(accounts.getBalance());
    }
}
