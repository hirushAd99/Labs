import com.MediumRoom;
import com.SmallRoom;

public class CreateRoom {
    
    public static void main(String[] args) {
        SmallRoom smallRoom = new SmallRoom();
        smallRoom.setBedType();
        smallRoom.setNoOfBed(1);
        smallRoom.setAC(false);
        smallRoom.tostring();
        MediumRoom mediumRoom01 = new MediumRoom();
        MediumRoom mediumRoom02 = new MediumRoom();

        mediumRoom01.setBedType();
        mediumRoom01.setNoOfBed(2);
        mediumRoom01.setAC(true);
        mediumRoom01.setFridge("Available");
        mediumRoom01.tostring();

        mediumRoom02.setBedType();
        mediumRoom02.setNoOfBed(2);
        mediumRoom02.setAC(false);
        mediumRoom02.setFridge("Available");
        mediumRoom02.tostring();

    }
}
