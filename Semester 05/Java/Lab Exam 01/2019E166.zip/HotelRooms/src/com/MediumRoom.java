package com;

public class MediumRoom extends Room {
    private String bedType;
    private String fridge;

    public String getBedType() {

        return bedType;
    }

    public void setBedType() {
        this.bedType = "Double";
    }

    public void setFridge(String fridge)
    {
        this.fridge = fridge;
    }

    public String getFridge()
    {
        return fridge;
    }

    public void tostring()
    {

        System.out.println("Type of Room : " + "Medium Room");
        System.out.println("Bed Type : " + bedType);
        System.out.println("Number of Beds : " + getNoOfBed());
        System.out.println("AC Machine " + getAC());
        System.out.println("Fridge : " + fridge + "\n");

    }



}
