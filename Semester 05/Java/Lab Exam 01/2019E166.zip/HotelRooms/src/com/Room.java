package com;
public class Room implements RoomInterface{
    private int noOfBed;
    public int getNoOfBed() {
        return this.noOfBed;
    }
    public void setNoOfBed(int noOfBed) {
        this.noOfBed = noOfBed;
    }
    public String getBedType() {
        return null;
    }

    
    public void setBedType() {
        //No need to implement here
    }

    @Override
    public void setAC(boolean isAvailable) {
    }

    @Override
    public boolean getAC() {
        return false;
    }

    public void tostring()
    {
    }

}
