package com;

public class SmallRoom extends Room{
    private String bedType;

    public String getBedType() {

        return bedType;
    }

    public void setBedType() {
        this.bedType = "Single";
    }

    public void tostring()
    {
        System.out.println("Type of Room : " + "Small Room");
        System.out.println("Bed Type : " + bedType);
        System.out.println("Number of Beds : " + getNoOfBed());
        System.out.println("AC Machine : " + getAC()+"\n");

    }

}
