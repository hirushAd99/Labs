package com;
public interface RoomInterface {
    public int getNoOfBed();
    public void setNoOfBed(int noOfBed);
    public String getBedType();
    public void setBedType();
    public void setAC(boolean isAvailable);
    public boolean getAC();

}
