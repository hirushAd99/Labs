package EC5080_Lab01;

import javax.lang.model.type.NullType;

public class Registration {
    int regno;
    String name;
    public void setDetails(int a,String b){
        regno=a;
        name=b;
    }
    public void showDetails(){
        System.out.println("Registration number is "+regno);
        System.out.println("Name is = "+name);
    }
    public static void main(String args[]){
        Registration s1 = new Registration();
        Registration s2 = new Registration();
        Registration s3 = new Registration();
        System.out.println("Created third reference variable and point it to s3");
        s1.setDetails(66,"Hirusha");
        s2.setDetails(66,"Adithya");

        s1.showDetails();
        s2.showDetails();
    }
}

