package EC5080_Lab01;

public class Message {
    String message;
    public Message(String msg) {
        this.message = msg;
    }
    public void display() {
        print(this.message);
    }
    public void print(String message) {
        Message msg = new Message("The message: " + message);
    }
    public static void main(String[] args) {
        Message msg_1 = new Message("SC1");
        Message msg_2 = new Message("SC2");
        msg_1 = msg_2;
        msg_1.display();
        new Message("SC3").display();
        msg_1 = null;
        System.gc();
    }
    public void finalize() {
        System.out.println("'" + this.message + "'" + " successfully garbage collected");
    }
}
