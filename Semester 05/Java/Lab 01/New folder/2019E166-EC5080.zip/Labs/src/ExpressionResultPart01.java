public class ExpressionResultPart01 {

}
