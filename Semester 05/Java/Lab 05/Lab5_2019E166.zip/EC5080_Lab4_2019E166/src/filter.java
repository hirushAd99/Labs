public class filter {
    //String[] strings =

}
