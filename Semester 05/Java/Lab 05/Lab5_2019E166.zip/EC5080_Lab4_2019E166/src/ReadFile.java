import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.StringTokenizer;

public class ReadFile {
    public static void main(String[] args) {
        try{
            File newFile = new File("C:/Users/RCS/Desktop/Software Construction/Lab 05/sampleText.txt");
            Scanner scannerText = new Scanner(newFile);
            while(scannerText.hasNextLine()){
                String data = scannerText.nextLine();
                filterMethod(data);
                System.out.println(data);
            }
        } catch (FileNotFoundException e) {
            System.out.println("Error occur.");
            throw new RuntimeException(e);
        }
    }
    public static void filterMethod(String line)
    {
        /**
        StringTokenizer stringTokenizer = new StringTokenizer(line,":,<>");
        while(stringTokenizer.hasMoreTokens())
        {
            System.out.println(stringTokenizer.nextToken());
        }
         **/
        StringTokenizer stringTokenizer = new StringTokenizer(line);
        line = String.valueOf(stringTokenizer);
        //StringTokenizer stringTokenizer1 = new StringTokenizer(line,":");




    }
}
