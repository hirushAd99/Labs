import org.junit.jupiter.api.Test;

import java.util.InputMismatchException;

import static org.junit.jupiter.api.Assertions.*;

class AccountsTest {
    Accounts accounts = new Accounts();
    @Test
    void testAccount()
    {

    }

    @Test
    void testMain() throws Exception {
        String accountNumber;
        double accountAmount;
        String[] userDetails = new String[2];
        accountNumber = "1953";
        assertArrayEquals(new String[]{"1953", "4275075.45"},accounts.findAccount(accountNumber));
        Accounts accounts1 = new Accounts(4275075.45,Integer.parseInt(accountNumber));
        assertEquals(4275075.45,accounts1.getBalance());
        accounts1.withdraw(accountNumber, 10000);
        assertEquals(4265075.45,accounts1.getBalance());
        accounts1.credit(accountNumber,20000);
        assertEquals(4285075.45,accounts1.getBalance());
        assertThrows(IllegalArgumentException.class,()->{accounts1.withdraw(accountNumber,-2000);});
        assertThrows(IllegalArgumentException.class,()->{accounts1.credit(accountNumber,-1000);});
        //assertEquals(IllegalArgumentException.class,()->{accounts1.});
    }

}