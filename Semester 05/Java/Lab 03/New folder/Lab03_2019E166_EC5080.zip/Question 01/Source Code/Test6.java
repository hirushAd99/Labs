public class Test6 {
    public static void func() throws ArithmeticException {
        int num = 10 / 0;
    }
    public static void main(String[] args) {
        func();
    }
}
