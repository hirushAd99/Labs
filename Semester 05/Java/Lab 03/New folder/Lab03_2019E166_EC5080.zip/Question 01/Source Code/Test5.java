public class Test5 {
    public static void func() {
        int num = 10 / 0;
    }

    public static void main(String[] args) {
        func();

    }
}
